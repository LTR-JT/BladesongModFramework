-- Bladesong UE5.7 FName constructor override
-- Built for Bladesong-Win64-Shipping.exe SHA256:
-- e4c761096f5cd3830d42256763b8828f17e6a24aba4d34c2f852936e60296cc7
--
-- Current EXE target:
-- RVA 0x127DBE0
--
-- This pattern identifies the explicit wide-character FName constructor
-- whose third argument is the EFindName mode.

local Signature =
    "48 89 5C 24 08 57 48 83 EC 30 " ..
    "48 8B D9 48 89 54 24 20 33 C9 " ..
    "41 8B F8 4C 8B D2 44 8B C9 48 85 D2 74 20"

function Register()
    return Signature
end

function OnMatchFound(MatchAddress)
    print(string.format(
        "[Bladesong FName Fix] Candidate matched at 0x%x",
        MatchAddress
    ))
    return MatchAddress
end
